from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    pass

class Posts(models.Model):
    
    content = models.CharField(max_length=500)
    user = models.ForeignKey(User,on_delete=models.CASCADE,related_name="poster")
    
    def __str__(self):
        return f"Post {self.id} posted by {self.user}"

class Followers(models.Model):
    user_following = models.ForeignKey(User,on_delete=models.CASCADE,related_name="user_following")
    user_followed = models.ForeignKey(User,on_delete=models.CASCADE,related_name="user_followed")
    
    def __str__(self):
        return f"{self.user_following} followed {self.user_followed}"

class Likes(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,related_name="user_liking")
    post = models.ForeignKey(Posts,on_delete=models.CASCADE,related_name="post_liked")
    
    def __str__(self):
        return f"{self.user} liked {self.post}"