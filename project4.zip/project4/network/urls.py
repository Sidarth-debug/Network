
from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("new_post",views.new_post,name="new_post"),
    path("view_profile/<int:user_id>",views.view_profile,name="view_profile"),
    path("follow",views.follow,name="follow"),
    path("unfollow",views.unfollow,name="unfollow"),
    path("following_page",views.following_page,name="following_page"),
    path("edit/<int:post_id>",views.edit,name="edit"),
    path("save_edit/<int:post_id>",views.save_edit,name="save_edit"),
    path("remove_like/<int:post_id>",views.remove_like,name="remove_like"),
    path("add_like/<int:post_id>",views.add_like,name="add_like"),
]
