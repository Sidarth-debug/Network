from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.core.paginator import Paginator
from .models import User,Posts,Followers,Likes
import json

def save_edit(request,post_id):
    if request.method == "POST":
       # print(request.body)
        #data = json.loads(request.body)
       # data = json.loads(request.body.decode('utf-8'))
        
        data = json.loads(request.body)
        original_value = Posts.objects.get(pk=post_id)
        original_value.content = data["content"]
        original_value.save()
        return HttpResponseRedirect(reverse("index"))


def remove_like(request,post_id):
    post_liked = Posts.objects.get(pk=post_id)
    user = User.objects.get(pk=request.user.id)
    like = Likes.objects.filter(user=user,post=post_liked)
    like.delete()
    return JsonResponse({"message":"Removed like from post"})


def add_like(request,post_id):
    post_liked = Posts.objects.get(pk=post_id)
    user = User.objects.get(pk=request.user.id)
    addLike = Likes(user=user,post=post_liked)
    addLike.save()
    return JsonResponse({"message":"Liked post"})

def index(request):
    posts = Posts.objects.all().order_by("id").reverse()
    paginator = Paginator(posts,10)
    page_no = request.GET.get('page')
    posts_in_page = paginator.get_page(page_no)
    likes = Likes.objects.all()
    posts_liked = []
    try:
        for like in likes:
            if request.user.id == like.user.id:
                posts_liked.append(like.post.id)
    except:
        posts_liked = []

    return render(request, "network/index.html",{
        "posts":posts,
        "posts_in_page":posts_in_page,
        "posts_liked":posts_liked
        
    })

def view_profile(request,user_id):
    user = User.objects.get(pk=user_id)
    posts = Posts.objects.filter(user=user)
    paginator = Paginator(posts,10)
    page_no = request.GET.get('page')
    posts_in_page = paginator.get_page(page_no)    
    following_user = Followers.objects.filter(user_following=user)
    try:
        checking_for_follow = following_user.filter(user=User.objects.get(pk=request.user.id))
        if len(checking_for_follow) != 0:
            is_following = True 
        else:
            is_following = False
    except:
        is_following = False


    following_count = 0
    for follower in following_user:
        following_count += 1
    followers = Followers.objects.filter(user_followed=user)
    follower_count = 0
    for follower in followers:
        follower_count+=1
    
    
    return render(request,"network/profile.html",{
        "posts":posts,
        "posts_in_page":posts_in_page,
        "username":user.username,
        "following_count":following_count,
        "follower_count":follower_count,
        "is_following":is_following,
        "following_user":user,
    })

def following_page(request):
    user = User.objects.get(pk=request.user.id)
    following_users = Followers.objects.filter(user_following=user)
    posts = Posts.objects.all().order_by('id').reverse()
    following_posts = []
    for post in posts:
         for single_user in following_users:
            if single_user.user_followed == post.user:
                following_posts.append(post) 

    paginator = Paginator(following_posts,10)
    page_no = request.GET.get('page')
    posts_in_page = paginator.get_page(page_no)
    return render(request, "network/following.html",{
        "posts":posts,
        "posts_in_page":posts_in_page,
        
    })


def new_post(request):
    if request.method == "POST":
        content = request.POST["content"]
        user = User.objects.get(id=request.user.id)
        p = Posts(content=content,user=user)
        p.save()
        return HttpResponseRedirect(reverse(index))

def follow(request):
    user_followed = request.POST['user_followed']
    user_following = User.objects.get(pk=request.user.id)
    user_followed_data = User.objects.get(username=user_followed)
    
    follow = Followers(user_following=user_following,user_followed=user_followed_data)
    follow.save()
    user_id = user_followed_data.id
    return HttpResponseRedirect(reverse(view_profile,kwargs={'user_id':user_id}))


def unfollow(request):
    user_followed = request.POST['user_unfollowed']
    user_following = User.objects.get(pk=request.user.id)
    user_followed_data = User.objects.get(username=user_followed)
    
    follow = Followers.objects.get(user_following=user_following,user_followed=user_followed_data)
    follow.delete() 
    user_id = user_followed_data.id
    return HttpResponseRedirect(reverse(view_profile,kwargs={'user_id':user_id}))
            
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "network/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "network/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))

def edit(request,post_id):
    
    posts = Posts.objects.get(pk=post_id)
   # paginator = Paginator(posts,10)
   # page_no = request.GET.get('page')
   # posts_in_page = paginator.get_page(page_no)
   # post_id = request.POST["post_id"]
    return render(request, "network/edit.html",{
        "posts":posts,
        #"posts_in_page":posts_in_page,
      #  "post_id":post_id
    })
            




    
def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "network/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "network/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "network/register.html")

'''def view_profile(request,user_id):
    user = User.objects.get(pk=user_id)
    posts = Posts.objects.all().order_by("id").reverse()

    following_users = Followers.objects.filter(user_following=user)
    followers = Followers.objects.filter(user_followed=user)

    try: 
        checking_for_follow = followers.objects.filter(user=User.objects.get(pk=request.user.id))
        if len(checking_for_follow) != 0:
            is_following = True
        else:
            is_following = False
    except:
        is_following = False
    paginator = Paginator(posts,10)
    page_no = request.GET.get('page')
    posts_in_page = paginator.get_page(page_no)
    return render(request, "network/profile.html",{
        "posts":posts,
        "posts_in_page":posts_in_page,
        "username":user.username,
        "following_users":following_users,
        "followers": followers,
        "is_following": is_following,
        "following_user" : user, 
    })

'''
